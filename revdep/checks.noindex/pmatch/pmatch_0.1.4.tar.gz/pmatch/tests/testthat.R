library(testthat)
library(pmatch)

test_check("pmatch")
